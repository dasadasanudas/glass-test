function run() {
  const se = Application('System Events'); const d = se.processes.byName('Dock'); let s = '';
  const els = d.lists[0].uiElements();
  for (const e of els) {
    let n = '', sr = ''; try { n = e.name() || ''; } catch (x) {} try { sr = e.subrole() || ''; } catch (x) {}
    try { const q = e.position(), z = e.size(); s += n + '\t' + sr + '\t' + q[0] + '\t' + q[1] + '\t' + z[0] + '\t' + z[1] + '\n'; } catch (x) {}
  }
  return s;
}
