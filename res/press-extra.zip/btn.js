function run(argv) {
  const se = Application('System Events'); const w = se.processes.byName(argv[0]).windows[0]; let s = '';
  const bs = w.buttons();
  for (const b of bs) { let sr = ''; try { sr = b.subrole() || ''; } catch (x) {} try { const q = b.position(), z = b.size(); s += sr + '\t' + q[0] + '\t' + q[1] + '\t' + z[0] + '\t' + z[1] + '\n'; } catch (x) {} }
  try { const q = w.position(), z = w.size(); s += 'window\t' + q[0] + '\t' + q[1] + '\t' + z[0] + '\t' + z[1] + '\n'; } catch (x) {}
  return s;
}
