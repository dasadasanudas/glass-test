function run(argv) {
  const se = Application('System Events'); let s = '';
  for (const pn of argv) {
    let bars = []; try { bars = se.processes.byName(pn).menuBars(); } catch (e) { continue; }
    for (let b = 0; b < bars.length; b++) {
      let items = []; try { items = bars[b].menuBarItems(); } catch (e) {}
      for (const it of items) {
        let n = '', d = '';
        try { n = it.name() || ''; } catch (e) {}
        try { d = it.description() || ''; } catch (e) {}
        try { const q = it.position(), z = it.size(); s += pn + '\t' + b + '\t' + n + '\t' + d + '\t' + q[0] + '\t' + q[1] + '\t' + z[0] + '\t' + z[1] + '\n'; } catch (e) {}
      }
    }
  }
  return s;
}
