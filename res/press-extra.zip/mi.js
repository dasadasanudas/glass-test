function run(argv) {
  const se = Application('System Events'); const p = se.processes.byName(argv[0]);
  const m = p.menuBars[0].menuBarItems.byName(argv[1]).menus[0]; let s = '';
  try { const q = m.position(), z = m.size(); s += '#menu\t' + q[0] + '\t' + q[1] + '\t' + z[0] + '\t' + z[1] + '\n'; } catch (e) {}
  const its = m.menuItems();
  for (const it of its) {
    let n = ''; try { n = it.name() || '-'; } catch (e) { n = '-'; }
    try { const q = it.position(), z = it.size(); s += n + '\t' + q[0] + '\t' + q[1] + '\t' + z[0] + '\t' + z[1] + '\n'; } catch (e) {}
  }
  return s;
}
