function run(argv) {
  const se = Application('System Events');
  const p = se.processes.whose({ frontmost: true })[0];
  const out = []; let n = 0;
  function walk(e, d) {
    if (n > 700 || d > 9) return;
    n++; const r = {};
    try { r.role = e.role(); } catch (x) {}
    try { r.sub = e.subrole(); } catch (x) {}
    try { r.name = e.name(); } catch (x) {}
    try { r.desc = e.description(); } catch (x) {}
    try { const v = e.value(); if (typeof v === 'string' || typeof v === 'number') r.value = String(v).slice(0, 60); } catch (x) {}
    try { r.pos = e.position(); r.size = e.size(); } catch (x) {}
    r.depth = d; out.push(r);
    let kids = []; try { kids = e.uiElements(); } catch (x) {}
    for (let i = 0; i < kids.length && i < 60; i++) walk(kids[i], d + 1);
  }
  try { walk(p.windows[0], 0); } catch (x) { out.push({ error: String(x) }); }
  return JSON.stringify(out);
}
